# LIVE STAR — Android APK starter project

**Brand:** LIVE STAR  
**Tagline:** Live • Connect • Play • Earn  
**Nepali tagline:** तपाईंको प्रतिभा, तपाईंको मञ्च!

This is a GitHub-ready Android Studio/Gradle starter project. The app currently packages the LIVE STAR interactive HTML prototype inside an Android WebView so GitHub Actions can build a debug APK.

## Included
- LIVE STAR demo interface and branding
- LIVE Battle demo screen with double-tap hearts and demo score interactions
- Four empty Guest `+` slots (UI demo only)
- Demo gifts, coins, points, profile/follow, AI companion placeholder and wallet screens where present in the prototype
- Android WebView wrapper
- GitHub Actions workflow: `.github/workflows/build-apk.yml`
- Logo artwork: `Live-Star-Logo.png`

## Build an APK on GitHub
1. Sign in to GitHub and create a new repository, e.g. `live-star-app`.
2. Extract this ZIP on your computer/phone and upload the **contents** of this folder to the repository root (not the ZIP file itself). Ensure `settings.gradle`, `build.gradle`, `app/`, and `.github/` are at the repository root.
3. Open the repository's **Actions** tab and enable Actions if asked.
4. Run **Build LIVE STAR APK** using **Run workflow**, or push a commit to `main`/`master`.
5. When the workflow succeeds, open its run, scroll to **Artifacts**, and download `LIVE-STAR-debug-APK`.
6. Extract the artifact ZIP to get `app-debug.apk`. On Android, allow installation from the source you used to download it, then install. Only install APKs you built or trust.

## Important limitations
This build is a prototype APK, not a production-ready social network. The live screen and Guest `+` slots are currently demonstration UI; actual multi-user audio/video requires a live-streaming provider and server. Accounts, chat delivery, moderation, real coin purchases, rewards, withdrawals/bank integration, and AI responses require backend services, security work, payment-provider setup, policy review, and testing. Wallet balances and scores in the demo are not real money and must not be advertised as withdrawable earnings.

## Before public release
- Add real backend, authentication, database, live video SDK and moderation tools.
- Implement privacy policy, terms, community guidelines and account deletion.
- Integrate payments only through approved providers and comply with Google Play policies and local law.
- Configure app signing securely for a release build; do not publish a debug APK as a final store release.

## Build both APK and AAB
The GitHub Actions workflow now runs `assembleDebug bundleDebug` and uploads two artifacts:
- `LIVE-STAR-debug-APK` → `app-debug.apk` (for installing/testing on Android)
- `LIVE-STAR-debug-AAB` → `app-debug.aab` (debug bundle for testing only)

Important: the debug AAB is **not a production Play Store release**. To publish on Google Play, create a properly signed release AAB using a private upload key, configure signing secrets securely in GitHub, and complete Play Console setup. Do not upload signing keys to the repository.


## Added welcome, language and sign-in UI
- First-launch language selector with English default and saved language preference.
- Google sign-in button and guest-demo entry.
- Important: Google sign-in is currently a UI placeholder, not real authentication. To activate it, create/configure a Firebase project, enable Google provider, add the Android app package `com.livestar.app`, configure SHA-1/SHA-256 fingerprints, download `google-services.json`, add Firebase Auth dependencies and implement native Google Credential Manager/Firebase sign-in. Do not claim accounts are secure/active until this is tested.
