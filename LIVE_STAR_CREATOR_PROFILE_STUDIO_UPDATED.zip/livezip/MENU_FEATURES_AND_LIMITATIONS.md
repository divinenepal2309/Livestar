# LIVE STAR menu update

Added a More/Information menu with app purpose, placeholder owner profile, creator media local preview, monetization transparency, community guidelines, privacy/security notes, language notes and contact placeholder. Added launcher icon resources derived from the existing logo.

Important: this remains a prototype. Public uploads, Google sign-in, live streaming, AI, real view/like/follower analytics, monetization calculations, and real USD/NPR withdrawals are not implemented by these UI changes. No official payout threshold or view-to-earning rate has been invented. The proposed $10 withdrawal threshold is not active until legal/payment integration and policy are completed.
